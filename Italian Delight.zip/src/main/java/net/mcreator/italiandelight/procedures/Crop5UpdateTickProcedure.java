package net.mcreator.italiandelight.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.BlockPos;

import net.mcreator.italiandelight.init.ItalianDelightModBlocks;

public class Crop5UpdateTickProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		if (Math.random() < 0.2) {
			world.setBlock(new BlockPos(x, y, z), ItalianDelightModBlocks.CROP_6.get().defaultBlockState(), 3);
		}
	}
}
